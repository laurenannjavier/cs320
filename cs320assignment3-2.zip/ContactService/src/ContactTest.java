import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContact() {
        Contact contact = new Contact("12345", "Lauren", "Javier", "1234567890", "365 Junior St");
        assertEquals("12345", contact.getContactId());
        assertEquals("Lauren", contact.getFirstName());
        assertEquals("Javier", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("365 Junior St", contact.getAddress());
    }

    @Test
    public void testContactSetters() {
        Contact contact = new Contact("12345", "Lauren", "Javier", "1234567890", "365 Junior St");
        contact.setFirstName("Mariel");
        contact.setLastName("Reyes");
        contact.setPhone("2345678901");
        contact.setAddress("926 Apple St");
        assertEquals("Mariel", contact.getFirstName());
        assertEquals("Reyes", contact.getLastName());
        assertEquals("2345678901", contact.getPhone());
        assertEquals("926 Apple St", contact.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Lauren", "Javier", "1234567890", "365 Junior St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Lauren", "Javier", "1234567890", "365 Junior St");
        });
    }

    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Javier", "1234567890", "365 Junior St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "LaurenLauren", "Javier", "1234567890", "365 Junior St");
        });
    }

    @Test
    public void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", null, "1234567890", "365 Junior St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", "JavierJavier", "1234567890", "365 Junior St");
        });
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", "Javier", null, "365 Junior St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", "Javier", "123456789", "365 Junior St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", "Javier", "12345678901", "365 Junior St");
        });
    }

    @Test
    public void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", "Javier", "1234567890", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Lauren", "Javier", "1234567890", "1234567890123456789012345678901");
        });
    }
}
