import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "Lauren", "Javier", "1234567890", "365 Junior St");
        service.addContact(contact);
        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "Lauren", "Javier", "1234567890", "365 Junior St");
        service.addContact(contact);
        service.deleteContact("12345");
        assertNull(service.getContact("12345"));
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("12345", "Lauren", "Javier", "1234567890", "365 Junior St");
        service.addContact(contact);
        service.updateContact("12345", "Mariel", "Reyes", "2345678901", "926 Apple St");
        assertEquals("Mariel", service.getContact("12345").getFirstName());
        assertEquals("Reyes", service.getContact("12345").getLastName());
        assertEquals("2345678901", service.getContact("12345").getPhone());
        assertEquals("926 Apple St", service.getContact("12345").getAddress());
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("12345", "Lauren", "Javier", "1234567890", "365 Junior St");
        Contact contact2 = new Contact("12345", "Mariel", "Reyes", "2345678901", "926 Apple St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContact("12345", "Mariel", "Reyes", "2345678901", "926 Apple St");
        });
    }

    @Test
    public void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("12345");
        });
    }

    @Test
    public void testAddInvalidContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact(null, "Lauren", "Javier", "1234567890", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345678901", "Lauren", "Javier", "1234567890", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", null, "Javier", "1234567890", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "LaurenLauren", "Javier", "1234567890", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", null, "1234567890", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", "JavierJavier", "1234567890", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", "Javier", null, "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", "Javier", "123456789", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", "Javier", "12345678901", "365 Junior St"));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", "Javier", "1234567890", null));
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("12345", "Lauren", "Javier", "1234567890", "1234567890123456789012345678901"));
        });
    }
}
